import UIKit
import StoreKit

class ViewController: UIViewController {

    private var inAppPurchaseModel = [SKProduct]()
    private var subscriptionModel: [Product: SKProduct] = [:]
    private var currentProduct: Product?

    @IBOutlet weak var appPurchaseButton: UIButton!
    @IBOutlet weak var weeklyButton: UIButton!
    @IBOutlet weak var monthlyButton: UIButton!
    @IBOutlet weak var yearlyButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
        requestInAppPurchaseProduct()
        requestSubscriptionProducts()

        SKPaymentQueue.default().add(self)
    }

    deinit {
        SKPaymentQueue.default().remove(self)
    }

    func setupUI() {
        appPurchaseButton.addTarget(self, action: #selector(purchaseInAppProduct), for: .touchUpInside)
        weeklyButton.addTarget(self, action: #selector(purchaseSubscription), for: .touchUpInside)
        monthlyButton.addTarget(self, action: #selector(purchaseSubscription), for: .touchUpInside)
        yearlyButton.addTarget(self, action: #selector(purchaseSubscription), for: .touchUpInside)
    }
 

    @objc func purchaseInAppProduct() {
        guard let product = inAppPurchaseModel.first else {
            // Handle error, product not available
            return
        }

        let payment = SKPayment(product: product)
        SKPaymentQueue.default().add(payment)
    }

    @objc func purchaseSubscription(sender: UIButton) {
        guard let productType = getProductType(for: sender) else {
            // Handle error, product type not recognized
            return
        }

        guard let product = subscriptionModel[productType] else {
            // Handle error, product not available
            return
        }

        currentProduct = productType

        let payment = SKPayment(product: product)
        SKPaymentQueue.default().add(payment)
    }

    private func getProductType(for button: UIButton) -> Product? {
        switch button {
        case weeklyButton:
            return .weekly
        case monthlyButton:
            return .monthly
        case yearlyButton:
            return .yearly
        default:
            return nil
        }
    }

    // MARK: - In-App Purchase

    private func requestInAppPurchaseProduct() {
        let request = SKProductsRequest(productIdentifiers: Set([Product.unlock.rawValue]))
        request.delegate = self
        request.start()
    }

    // MARK: - Subscription

    private func requestSubscriptionProducts() {
        let productIdentifiers: Set<String> = [Product.weekly.rawValue,
                                              Product.monthly.rawValue,
                                              Product.yearly.rawValue]

        let request = SKProductsRequest(productIdentifiers: productIdentifiers)
        request.delegate = self
        request.start()
    }

    // MARK: - SKProductsRequestDelegate
    private func handlePurchaseSuccess(_ transaction: SKPaymentTransaction) {
        guard let product = currentProduct else {
            // Handle unexpected state
            return
        }

        switch product {
        case .unlock:
            // Handle successful purchase for in-app product
            break
        case .weekly, .monthly, .yearly:
            // Handle successful purchase for subscription
            break
        }

        // Finish the transaction
        finishTransaction(transaction)
    }

    private func handlePurchaseFailure(_ transaction: SKPaymentTransaction) {
        // Handle failed purchase
        finishTransaction(transaction)
    }

    private func handlePurchaseRestoration(_ transaction: SKPaymentTransaction) {
        // Handle restored purchase
        finishTransaction(transaction)
    }

    private func finishTransaction(_ transaction: SKPaymentTransaction) {
        SKPaymentQueue.default().finishTransaction(transaction)
    }
}

enum Product: String {
    case unlock = "com.InAppPurchase.unlock"
    case weekly = "com.InAppPurchase.weekly"
    case monthly = "com.InAppPurchase.monthly"
    case yearly = "com.InAppPurchase.yearly"
}



extension ViewController: SKProductsRequestDelegate, SKPaymentTransactionObserver {
    
    func productsRequest(_ request: SKProductsRequest, didReceive response: SKProductsResponse) {
        for product in response.products {
            if let productType = Product(rawValue: product.productIdentifier) {
                if response.invalidProductIdentifiers.contains(product.productIdentifier) {
                    // Handle invalid product identifier
                    continue
                }

                if productType == .unlock {
                    inAppPurchaseModel.append(product)
                } else {
                    subscriptionModel[productType] = product
                }
            }
        }
    }

    // MARK: - SKPaymentTransactionObserver

    func paymentQueue(_ queue: SKPaymentQueue, updatedTransactions transactions: [SKPaymentTransaction]) {
        for transaction in transactions {
            switch transaction.transactionState {
            case .purchased:
                handlePurchaseSuccess(transaction)
            case .failed:
                handlePurchaseFailure(transaction)
            case .restored:
                handlePurchaseRestoration(transaction)
            default:
                break
            }
        }
    }
    
}
